﻿namespace Phone1st.Forms
{
    partial class CompanyMain
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnNew = new System.Windows.Forms.Button();
            this.lblError = new System.Windows.Forms.Label();
            this.txtMemo = new System.Windows.Forms.TextBox();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.txtHp = new System.Windows.Forms.TextBox();
            this.txtTel = new System.Windows.Forms.TextBox();
            this.txtAddr = new System.Windows.Forms.TextBox();
            this.txtBank = new System.Windows.Forms.TextBox();
            this.txtBankNo = new System.Windows.Forms.TextBox();
            this.txtBankOwner = new System.Windows.Forms.TextBox();
            this.txtCompany = new System.Windows.Forms.TextBox();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblRegister = new System.Windows.Forms.Label();
            this.lblCode = new System.Windows.Forms.Label();
            this.lblCodeName = new System.Windows.Forms.Label();
            this.lblTitle2 = new System.Windows.Forms.Label();
            this.lblTitle1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTest = new System.Windows.Forms.Label();
            this.SellerList = new System.Windows.Forms.DataGridView();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.hidLine9 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.hidLine8 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.hidLine7 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.hidLine6 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.hidLine5 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.hidLine4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape13 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape12 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape11 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.hidLine3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.hidLine2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.hidLine1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape10 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape9 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape8 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape7 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape6 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape5 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblError2 = new System.Windows.Forms.Label();
            this.txtMemo2 = new System.Windows.Forms.TextBox();
            this.txtContact2 = new System.Windows.Forms.TextBox();
            this.txtHp2 = new System.Windows.Forms.TextBox();
            this.txtTel2 = new System.Windows.Forms.TextBox();
            this.txtAddr2 = new System.Windows.Forms.TextBox();
            this.txtBank2 = new System.Windows.Forms.TextBox();
            this.txtBankNo2 = new System.Windows.Forms.TextBox();
            this.txtBankOwner2 = new System.Windows.Forms.TextBox();
            this.txtCompany2 = new System.Windows.Forms.TextBox();
            this.lblDate2 = new System.Windows.Forms.Label();
            this.lblRegister2 = new System.Windows.Forms.Label();
            this.lblCode2 = new System.Windows.Forms.Label();
            this.lblCodeName2 = new System.Windows.Forms.Label();
            this.lblTitle12 = new System.Windows.Forms.Label();
            this.lblTitle11 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.btnDel2 = new System.Windows.Forms.Button();
            this.btnSave2 = new System.Windows.Forms.Button();
            this.btnNew2 = new System.Windows.Forms.Button();
            this.buyerList = new System.Windows.Forms.DataGridView();
            this.shapeContainer2 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape35 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape34 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape33 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape32 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape31 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape30 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape29 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape28 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape27 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape26 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.hidLine28 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.hidLine29 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.hidLine21 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape22 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape21 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape20 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.hidLine22 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.hidLine23 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.hidLine24 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.hidLine25 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.hidLine26 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.hidLine27 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SellerList)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.buyerList)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(5, 5);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1248, 652);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnDelete);
            this.tabPage1.Controls.Add(this.btnSave);
            this.tabPage1.Controls.Add(this.btnNew);
            this.tabPage1.Controls.Add(this.lblError);
            this.tabPage1.Controls.Add(this.txtMemo);
            this.tabPage1.Controls.Add(this.txtContact);
            this.tabPage1.Controls.Add(this.txtHp);
            this.tabPage1.Controls.Add(this.txtTel);
            this.tabPage1.Controls.Add(this.txtAddr);
            this.tabPage1.Controls.Add(this.txtBank);
            this.tabPage1.Controls.Add(this.txtBankNo);
            this.tabPage1.Controls.Add(this.txtBankOwner);
            this.tabPage1.Controls.Add(this.txtCompany);
            this.tabPage1.Controls.Add(this.lblDate);
            this.tabPage1.Controls.Add(this.lblRegister);
            this.tabPage1.Controls.Add(this.lblCode);
            this.tabPage1.Controls.Add(this.lblCodeName);
            this.tabPage1.Controls.Add(this.lblTitle2);
            this.tabPage1.Controls.Add(this.lblTitle1);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.lblTest);
            this.tabPage1.Controls.Add(this.SellerList);
            this.tabPage1.Controls.Add(this.shapeContainer1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1240, 626);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "매도 업체 관리";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("굴림", 9F);
            this.btnDelete.Image = global::Phone1st.Properties.Resources._123;
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.Location = new System.Drawing.Point(1077, 451);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(60, 23);
            this.btnDelete.TabIndex = 1002;
            this.btnDelete.Text = "삭제";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("굴림", 9F);
            this.btnSave.Image = global::Phone1st.Properties.Resources.saveHS1;
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(1001, 451);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(60, 23);
            this.btnSave.TabIndex = 1001;
            this.btnSave.Text = "저장";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnNew
            // 
            this.btnNew.Font = new System.Drawing.Font("굴림", 9F);
            this.btnNew.Image = global::Phone1st.Properties.Resources.NewCardHS1;
            this.btnNew.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNew.Location = new System.Drawing.Point(921, 451);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(60, 23);
            this.btnNew.TabIndex = 1000;
            this.btnNew.Text = "신규";
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNew.UseVisualStyleBackColor = true;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblError.ForeColor = System.Drawing.Color.Red;
            this.lblError.Location = new System.Drawing.Point(830, 490);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(37, 12);
            this.lblError.TabIndex = 31;
            this.lblError.Text = "Error";
            // 
            // txtMemo
            // 
            this.txtMemo.Location = new System.Drawing.Point(930, 300);
            this.txtMemo.Multiline = true;
            this.txtMemo.Name = "txtMemo";
            this.txtMemo.Size = new System.Drawing.Size(269, 69);
            this.txtMemo.TabIndex = 8;
            // 
            // txtContact
            // 
            this.txtContact.Location = new System.Drawing.Point(930, 90);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(269, 21);
            this.txtContact.TabIndex = 1;
            // 
            // txtHp
            // 
            this.txtHp.Location = new System.Drawing.Point(930, 120);
            this.txtHp.Name = "txtHp";
            this.txtHp.Size = new System.Drawing.Size(269, 21);
            this.txtHp.TabIndex = 2;
            // 
            // txtTel
            // 
            this.txtTel.Location = new System.Drawing.Point(930, 150);
            this.txtTel.Name = "txtTel";
            this.txtTel.Size = new System.Drawing.Size(269, 21);
            this.txtTel.TabIndex = 3;
            // 
            // txtAddr
            // 
            this.txtAddr.Location = new System.Drawing.Point(930, 180);
            this.txtAddr.Name = "txtAddr";
            this.txtAddr.Size = new System.Drawing.Size(269, 21);
            this.txtAddr.TabIndex = 4;
            // 
            // txtBank
            // 
            this.txtBank.Location = new System.Drawing.Point(930, 210);
            this.txtBank.Name = "txtBank";
            this.txtBank.Size = new System.Drawing.Size(269, 21);
            this.txtBank.TabIndex = 5;
            // 
            // txtBankNo
            // 
            this.txtBankNo.Location = new System.Drawing.Point(930, 240);
            this.txtBankNo.Name = "txtBankNo";
            this.txtBankNo.Size = new System.Drawing.Size(269, 21);
            this.txtBankNo.TabIndex = 6;
            // 
            // txtBankOwner
            // 
            this.txtBankOwner.Location = new System.Drawing.Point(930, 270);
            this.txtBankOwner.Name = "txtBankOwner";
            this.txtBankOwner.Size = new System.Drawing.Size(269, 21);
            this.txtBankOwner.TabIndex = 7;
            // 
            // txtCompany
            // 
            this.txtCompany.Location = new System.Drawing.Point(930, 60);
            this.txtCompany.Name = "txtCompany";
            this.txtCompany.Size = new System.Drawing.Size(269, 21);
            this.txtCompany.TabIndex = 0;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblDate.Location = new System.Drawing.Point(930, 410);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(41, 12);
            this.lblDate.TabIndex = 20;
            this.lblDate.Text = "등록일";
            // 
            // lblRegister
            // 
            this.lblRegister.AutoSize = true;
            this.lblRegister.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblRegister.Location = new System.Drawing.Point(930, 380);
            this.lblRegister.Name = "lblRegister";
            this.lblRegister.Size = new System.Drawing.Size(41, 12);
            this.lblRegister.TabIndex = 19;
            this.lblRegister.Text = "Admin";
            // 
            // lblCode
            // 
            this.lblCode.AutoSize = true;
            this.lblCode.Font = new System.Drawing.Font("굴림", 9F);
            this.lblCode.Location = new System.Drawing.Point(930, 30);
            this.lblCode.Name = "lblCode";
            this.lblCode.Size = new System.Drawing.Size(53, 12);
            this.lblCode.TabIndex = 20;
            this.lblCode.Text = "업체코드";
            // 
            // lblCodeName
            // 
            this.lblCodeName.AutoSize = true;
            this.lblCodeName.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblCodeName.Location = new System.Drawing.Point(840, 30);
            this.lblCodeName.Name = "lblCodeName";
            this.lblCodeName.Size = new System.Drawing.Size(57, 12);
            this.lblCodeName.TabIndex = 21;
            this.lblCodeName.Text = "업체코드";
            // 
            // lblTitle2
            // 
            this.lblTitle2.AutoSize = true;
            this.lblTitle2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblTitle2.Location = new System.Drawing.Point(840, 410);
            this.lblTitle2.Name = "lblTitle2";
            this.lblTitle2.Size = new System.Drawing.Size(44, 12);
            this.lblTitle2.TabIndex = 33;
            this.lblTitle2.Text = "등록일";
            // 
            // lblTitle1
            // 
            this.lblTitle1.AutoSize = true;
            this.lblTitle1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblTitle1.Location = new System.Drawing.Point(840, 380);
            this.lblTitle1.Name = "lblTitle1";
            this.lblTitle1.Size = new System.Drawing.Size(44, 12);
            this.lblTitle1.TabIndex = 32;
            this.lblTitle1.Text = "등록자";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label10.Location = new System.Drawing.Point(840, 300);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(31, 12);
            this.label10.TabIndex = 30;
            this.label10.Text = "메모";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label8.Location = new System.Drawing.Point(840, 270);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 12);
            this.label8.TabIndex = 29;
            this.label8.Text = "예금주";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(840, 150);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 12);
            this.label7.TabIndex = 25;
            this.label7.Text = "연락처";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(840, 240);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 12);
            this.label6.TabIndex = 28;
            this.label6.Text = "계좌번호";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(840, 120);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 12);
            this.label5.TabIndex = 24;
            this.label5.Text = "핸드폰";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(840, 180);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 12);
            this.label4.TabIndex = 26;
            this.label4.Text = "주소";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(840, 210);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 12);
            this.label3.TabIndex = 27;
            this.label3.Text = "은행명";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(840, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 12);
            this.label2.TabIndex = 23;
            this.label2.Text = "담당자명";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(840, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 12);
            this.label1.TabIndex = 22;
            this.label1.Text = "매입처명";
            // 
            // lblTest
            // 
            this.lblTest.AutoSize = true;
            this.lblTest.Location = new System.Drawing.Point(7, 17);
            this.lblTest.Name = "lblTest";
            this.lblTest.Size = new System.Drawing.Size(0, 12);
            this.lblTest.TabIndex = 1;
            // 
            // SellerList
            // 
            this.SellerList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.SellerList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.SellerList.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.SellerList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.SellerList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SellerList.Location = new System.Drawing.Point(9, 15);
            this.SellerList.Name = "SellerList";
            this.SellerList.RowTemplate.Height = 23;
            this.SellerList.Size = new System.Drawing.Size(795, 533);
            this.SellerList.TabIndex = 999;
            this.SellerList.Click += new System.EventHandler(this.SellerList_Click);
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(3, 3);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.hidLine9,
            this.hidLine8,
            this.hidLine7,
            this.hidLine6,
            this.hidLine5,
            this.hidLine4,
            this.lineShape13,
            this.lineShape12,
            this.lineShape11,
            this.hidLine3,
            this.hidLine2,
            this.hidLine1,
            this.lineShape10,
            this.lineShape9,
            this.lineShape8,
            this.lineShape7,
            this.lineShape6,
            this.lineShape5,
            this.lineShape4,
            this.lineShape3,
            this.lineShape2,
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(1234, 620);
            this.shapeContainer1.TabIndex = 1003;
            this.shapeContainer1.TabStop = false;
            // 
            // hidLine9
            // 
            this.hidLine9.Name = "hidLine9";
            this.hidLine9.X1 = 1200;
            this.hidLine9.X2 = 1200;
            this.hidLine9.Y1 = 370;
            this.hidLine9.Y2 = 430;
            // 
            // hidLine8
            // 
            this.hidLine8.Name = "hidLine8";
            this.hidLine8.X1 = 910;
            this.hidLine8.X2 = 910;
            this.hidLine8.Y1 = 370;
            this.hidLine8.Y2 = 430;
            // 
            // hidLine7
            // 
            this.hidLine7.Name = "hidLine7";
            this.hidLine7.X1 = 830;
            this.hidLine7.X2 = 830;
            this.hidLine7.Y1 = 370;
            this.hidLine7.Y2 = 430;
            // 
            // hidLine6
            // 
            this.hidLine6.Name = "hidLine6";
            this.hidLine6.X1 = 1200;
            this.hidLine6.X2 = 1200;
            this.hidLine6.Y1 = 21;
            this.hidLine6.Y2 = 51;
            // 
            // hidLine5
            // 
            this.hidLine5.Name = "hidLine5";
            this.hidLine5.X1 = 910;
            this.hidLine5.X2 = 910;
            this.hidLine5.Y1 = 21;
            this.hidLine5.Y2 = 51;
            // 
            // hidLine4
            // 
            this.hidLine4.Name = "hidLine4";
            this.hidLine4.X1 = 830;
            this.hidLine4.X2 = 830;
            this.hidLine4.Y1 = 21;
            this.hidLine4.Y2 = 51;
            // 
            // lineShape13
            // 
            this.lineShape13.Name = "lineShape13";
            this.lineShape13.X1 = 910;
            this.lineShape13.X2 = 910;
            this.lineShape13.Y1 = 51;
            this.lineShape13.Y2 = 370;
            // 
            // lineShape12
            // 
            this.lineShape12.Name = "lineShape12";
            this.lineShape12.X1 = 1200;
            this.lineShape12.X2 = 1200;
            this.lineShape12.Y1 = 51;
            this.lineShape12.Y2 = 370;
            // 
            // lineShape11
            // 
            this.lineShape11.Name = "lineShape11";
            this.lineShape11.X1 = 830;
            this.lineShape11.X2 = 830;
            this.lineShape11.Y1 = 51;
            this.lineShape11.Y2 = 370;
            // 
            // hidLine3
            // 
            this.hidLine3.Name = "hidLine3";
            this.hidLine3.X1 = 830;
            this.hidLine3.X2 = 1200;
            this.hidLine3.Y1 = 21;
            this.hidLine3.Y2 = 21;
            // 
            // hidLine2
            // 
            this.hidLine2.Name = "hidLine2";
            this.hidLine2.X1 = 830;
            this.hidLine2.X2 = 1200;
            this.hidLine2.Y1 = 430;
            this.hidLine2.Y2 = 430;
            // 
            // hidLine1
            // 
            this.hidLine1.Name = "hidLine1";
            this.hidLine1.X1 = 830;
            this.hidLine1.X2 = 1200;
            this.hidLine1.Y1 = 400;
            this.hidLine1.Y2 = 400;
            // 
            // lineShape10
            // 
            this.lineShape10.Name = "lineShape10";
            this.lineShape10.X1 = 830;
            this.lineShape10.X2 = 1200;
            this.lineShape10.Y1 = 370;
            this.lineShape10.Y2 = 370;
            // 
            // lineShape9
            // 
            this.lineShape9.Name = "lineShape9";
            this.lineShape9.X1 = 830;
            this.lineShape9.X2 = 1200;
            this.lineShape9.Y1 = 291;
            this.lineShape9.Y2 = 291;
            // 
            // lineShape8
            // 
            this.lineShape8.Name = "lineShape8";
            this.lineShape8.X1 = 830;
            this.lineShape8.X2 = 1200;
            this.lineShape8.Y1 = 261;
            this.lineShape8.Y2 = 261;
            // 
            // lineShape7
            // 
            this.lineShape7.Name = "lineShape7";
            this.lineShape7.X1 = 830;
            this.lineShape7.X2 = 1200;
            this.lineShape7.Y1 = 231;
            this.lineShape7.Y2 = 231;
            // 
            // lineShape6
            // 
            this.lineShape6.Name = "lineShape6";
            this.lineShape6.X1 = 830;
            this.lineShape6.X2 = 1200;
            this.lineShape6.Y1 = 201;
            this.lineShape6.Y2 = 201;
            // 
            // lineShape5
            // 
            this.lineShape5.Name = "lineShape5";
            this.lineShape5.X1 = 830;
            this.lineShape5.X2 = 1200;
            this.lineShape5.Y1 = 171;
            this.lineShape5.Y2 = 171;
            // 
            // lineShape4
            // 
            this.lineShape4.Name = "lineShape4";
            this.lineShape4.X1 = 830;
            this.lineShape4.X2 = 1200;
            this.lineShape4.Y1 = 141;
            this.lineShape4.Y2 = 141;
            // 
            // lineShape3
            // 
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 830;
            this.lineShape3.X2 = 1200;
            this.lineShape3.Y1 = 111;
            this.lineShape3.Y2 = 111;
            // 
            // lineShape2
            // 
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 830;
            this.lineShape2.X2 = 1200;
            this.lineShape2.Y1 = 81;
            this.lineShape2.Y2 = 81;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 830;
            this.lineShape1.X2 = 1200;
            this.lineShape1.Y1 = 51;
            this.lineShape1.Y2 = 51;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lblError2);
            this.tabPage2.Controls.Add(this.txtMemo2);
            this.tabPage2.Controls.Add(this.txtContact2);
            this.tabPage2.Controls.Add(this.txtHp2);
            this.tabPage2.Controls.Add(this.txtTel2);
            this.tabPage2.Controls.Add(this.txtAddr2);
            this.tabPage2.Controls.Add(this.txtBank2);
            this.tabPage2.Controls.Add(this.txtBankNo2);
            this.tabPage2.Controls.Add(this.txtBankOwner2);
            this.tabPage2.Controls.Add(this.txtCompany2);
            this.tabPage2.Controls.Add(this.lblDate2);
            this.tabPage2.Controls.Add(this.lblRegister2);
            this.tabPage2.Controls.Add(this.lblCode2);
            this.tabPage2.Controls.Add(this.lblCodeName2);
            this.tabPage2.Controls.Add(this.lblTitle12);
            this.tabPage2.Controls.Add(this.lblTitle11);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.label22);
            this.tabPage2.Controls.Add(this.label23);
            this.tabPage2.Controls.Add(this.label24);
            this.tabPage2.Controls.Add(this.label25);
            this.tabPage2.Controls.Add(this.label26);
            this.tabPage2.Controls.Add(this.label27);
            this.tabPage2.Controls.Add(this.btnDel2);
            this.tabPage2.Controls.Add(this.btnSave2);
            this.tabPage2.Controls.Add(this.btnNew2);
            this.tabPage2.Controls.Add(this.buyerList);
            this.tabPage2.Controls.Add(this.shapeContainer2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1240, 626);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "매입 업체 관리";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lblError2
            // 
            this.lblError2.AutoSize = true;
            this.lblError2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblError2.ForeColor = System.Drawing.Color.Red;
            this.lblError2.Location = new System.Drawing.Point(830, 490);
            this.lblError2.Name = "lblError2";
            this.lblError2.Size = new System.Drawing.Size(37, 12);
            this.lblError2.TabIndex = 1027;
            this.lblError2.Text = "Error";
            // 
            // txtMemo2
            // 
            this.txtMemo2.Location = new System.Drawing.Point(930, 301);
            this.txtMemo2.Multiline = true;
            this.txtMemo2.Name = "txtMemo2";
            this.txtMemo2.Size = new System.Drawing.Size(269, 69);
            this.txtMemo2.TabIndex = 1008;
            // 
            // txtContact2
            // 
            this.txtContact2.Location = new System.Drawing.Point(930, 91);
            this.txtContact2.Name = "txtContact2";
            this.txtContact2.Size = new System.Drawing.Size(269, 21);
            this.txtContact2.TabIndex = 1001;
            // 
            // txtHp2
            // 
            this.txtHp2.Location = new System.Drawing.Point(930, 121);
            this.txtHp2.Name = "txtHp2";
            this.txtHp2.Size = new System.Drawing.Size(269, 21);
            this.txtHp2.TabIndex = 1002;
            // 
            // txtTel2
            // 
            this.txtTel2.Location = new System.Drawing.Point(930, 151);
            this.txtTel2.Name = "txtTel2";
            this.txtTel2.Size = new System.Drawing.Size(269, 21);
            this.txtTel2.TabIndex = 1003;
            // 
            // txtAddr2
            // 
            this.txtAddr2.Location = new System.Drawing.Point(930, 181);
            this.txtAddr2.Name = "txtAddr2";
            this.txtAddr2.Size = new System.Drawing.Size(269, 21);
            this.txtAddr2.TabIndex = 1004;
            // 
            // txtBank2
            // 
            this.txtBank2.Location = new System.Drawing.Point(930, 211);
            this.txtBank2.Name = "txtBank2";
            this.txtBank2.Size = new System.Drawing.Size(269, 21);
            this.txtBank2.TabIndex = 1005;
            // 
            // txtBankNo2
            // 
            this.txtBankNo2.Location = new System.Drawing.Point(930, 241);
            this.txtBankNo2.Name = "txtBankNo2";
            this.txtBankNo2.Size = new System.Drawing.Size(269, 21);
            this.txtBankNo2.TabIndex = 1006;
            // 
            // txtBankOwner2
            // 
            this.txtBankOwner2.Location = new System.Drawing.Point(930, 271);
            this.txtBankOwner2.Name = "txtBankOwner2";
            this.txtBankOwner2.Size = new System.Drawing.Size(269, 21);
            this.txtBankOwner2.TabIndex = 1007;
            // 
            // txtCompany2
            // 
            this.txtCompany2.Location = new System.Drawing.Point(930, 61);
            this.txtCompany2.Name = "txtCompany2";
            this.txtCompany2.Size = new System.Drawing.Size(269, 21);
            this.txtCompany2.TabIndex = 1000;
            // 
            // lblDate2
            // 
            this.lblDate2.AutoSize = true;
            this.lblDate2.Font = new System.Drawing.Font("굴림", 9F);
            this.lblDate2.Location = new System.Drawing.Point(930, 410);
            this.lblDate2.Name = "lblDate2";
            this.lblDate2.Size = new System.Drawing.Size(41, 12);
            this.lblDate2.TabIndex = 1014;
            this.lblDate2.Text = "등록일";
            // 
            // lblRegister2
            // 
            this.lblRegister2.AutoSize = true;
            this.lblRegister2.Font = new System.Drawing.Font("굴림", 9F);
            this.lblRegister2.Location = new System.Drawing.Point(930, 380);
            this.lblRegister2.Name = "lblRegister2";
            this.lblRegister2.Size = new System.Drawing.Size(41, 12);
            this.lblRegister2.TabIndex = 1013;
            this.lblRegister2.Text = "Admin";
            // 
            // lblCode2
            // 
            this.lblCode2.AutoSize = true;
            this.lblCode2.Font = new System.Drawing.Font("굴림", 9F);
            this.lblCode2.Location = new System.Drawing.Point(930, 30);
            this.lblCode2.Name = "lblCode2";
            this.lblCode2.Size = new System.Drawing.Size(53, 12);
            this.lblCode2.TabIndex = 1015;
            this.lblCode2.Text = "업체코드";
            // 
            // lblCodeName2
            // 
            this.lblCodeName2.AutoSize = true;
            this.lblCodeName2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold);
            this.lblCodeName2.Location = new System.Drawing.Point(840, 30);
            this.lblCodeName2.Name = "lblCodeName2";
            this.lblCodeName2.Size = new System.Drawing.Size(57, 12);
            this.lblCodeName2.TabIndex = 1016;
            this.lblCodeName2.Text = "업체코드";
            // 
            // lblTitle12
            // 
            this.lblTitle12.AutoSize = true;
            this.lblTitle12.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblTitle12.Location = new System.Drawing.Point(840, 410);
            this.lblTitle12.Name = "lblTitle12";
            this.lblTitle12.Size = new System.Drawing.Size(44, 12);
            this.lblTitle12.TabIndex = 1029;
            this.lblTitle12.Text = "등록일";
            // 
            // lblTitle11
            // 
            this.lblTitle11.AutoSize = true;
            this.lblTitle11.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblTitle11.Location = new System.Drawing.Point(840, 380);
            this.lblTitle11.Name = "lblTitle11";
            this.lblTitle11.Size = new System.Drawing.Size(44, 12);
            this.lblTitle11.TabIndex = 1028;
            this.lblTitle11.Text = "등록자";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label18.Location = new System.Drawing.Point(840, 301);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(31, 12);
            this.label18.TabIndex = 1025;
            this.label18.Text = "메모";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label20.Location = new System.Drawing.Point(840, 271);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(44, 12);
            this.label20.TabIndex = 1024;
            this.label20.Text = "예금주";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold);
            this.label21.Location = new System.Drawing.Point(840, 151);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(44, 12);
            this.label21.TabIndex = 1020;
            this.label21.Text = "연락처";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label22.Location = new System.Drawing.Point(840, 241);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(57, 12);
            this.label22.TabIndex = 1023;
            this.label22.Text = "계좌번호";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold);
            this.label23.Location = new System.Drawing.Point(840, 121);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(44, 12);
            this.label23.TabIndex = 1019;
            this.label23.Text = "핸드폰";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold);
            this.label24.Location = new System.Drawing.Point(840, 181);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(31, 12);
            this.label24.TabIndex = 1021;
            this.label24.Text = "주소";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold);
            this.label25.Location = new System.Drawing.Point(840, 211);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(44, 12);
            this.label25.TabIndex = 1022;
            this.label25.Text = "은행명";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold);
            this.label26.Location = new System.Drawing.Point(840, 91);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(57, 12);
            this.label26.TabIndex = 1018;
            this.label26.Text = "담당자명";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold);
            this.label27.Location = new System.Drawing.Point(840, 61);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(57, 12);
            this.label27.TabIndex = 1017;
            this.label27.Text = "매입처명";
            // 
            // btnDel2
            // 
            this.btnDel2.Image = global::Phone1st.Properties.Resources._123;
            this.btnDel2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDel2.Location = new System.Drawing.Point(1077, 451);
            this.btnDel2.Name = "btnDel2";
            this.btnDel2.Size = new System.Drawing.Size(60, 23);
            this.btnDel2.TabIndex = 1012;
            this.btnDel2.Text = "삭제";
            this.btnDel2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDel2.UseVisualStyleBackColor = true;
            this.btnDel2.Click += new System.EventHandler(this.btnDel2_Click);
            // 
            // btnSave2
            // 
            this.btnSave2.Image = global::Phone1st.Properties.Resources.saveHS1;
            this.btnSave2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave2.Location = new System.Drawing.Point(1001, 451);
            this.btnSave2.Name = "btnSave2";
            this.btnSave2.Size = new System.Drawing.Size(60, 23);
            this.btnSave2.TabIndex = 1011;
            this.btnSave2.Text = "저장";
            this.btnSave2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave2.UseVisualStyleBackColor = true;
            this.btnSave2.Click += new System.EventHandler(this.btnSave2_Click);
            // 
            // btnNew2
            // 
            this.btnNew2.Image = global::Phone1st.Properties.Resources.NewCardHS1;
            this.btnNew2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNew2.Location = new System.Drawing.Point(921, 451);
            this.btnNew2.Name = "btnNew2";
            this.btnNew2.Size = new System.Drawing.Size(60, 23);
            this.btnNew2.TabIndex = 1010;
            this.btnNew2.Text = "신규";
            this.btnNew2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNew2.UseVisualStyleBackColor = true;
            this.btnNew2.Click += new System.EventHandler(this.btnNew2_Click);
            // 
            // buyerList
            // 
            this.buyerList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.buyerList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.buyerList.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.buyerList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.buyerList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.buyerList.Location = new System.Drawing.Point(9, 15);
            this.buyerList.Name = "buyerList";
            this.buyerList.RowTemplate.Height = 23;
            this.buyerList.Size = new System.Drawing.Size(795, 533);
            this.buyerList.TabIndex = 1030;
            this.buyerList.Click += new System.EventHandler(this.buyerList_Click);
            // 
            // shapeContainer2
            // 
            this.shapeContainer2.Location = new System.Drawing.Point(3, 3);
            this.shapeContainer2.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer2.Name = "shapeContainer2";
            this.shapeContainer2.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape35,
            this.lineShape34,
            this.lineShape33,
            this.lineShape32,
            this.lineShape31,
            this.lineShape30,
            this.lineShape29,
            this.lineShape28,
            this.lineShape27,
            this.lineShape26,
            this.hidLine28,
            this.hidLine29,
            this.hidLine21,
            this.lineShape22,
            this.lineShape21,
            this.lineShape20,
            this.hidLine22,
            this.hidLine23,
            this.hidLine24,
            this.hidLine25,
            this.hidLine26,
            this.hidLine27});
            this.shapeContainer2.Size = new System.Drawing.Size(1234, 620);
            this.shapeContainer2.TabIndex = 1031;
            this.shapeContainer2.TabStop = false;
            // 
            // lineShape35
            // 
            this.lineShape35.Name = "lineShape35";
            this.lineShape35.X1 = 1200;
            this.lineShape35.X2 = 1200;
            this.lineShape35.Y1 = 51;
            this.lineShape35.Y2 = 370;
            // 
            // lineShape34
            // 
            this.lineShape34.Name = "lineShape34";
            this.lineShape34.X1 = 910;
            this.lineShape34.X2 = 910;
            this.lineShape34.Y1 = 51;
            this.lineShape34.Y2 = 370;
            // 
            // lineShape33
            // 
            this.lineShape33.Name = "lineShape33";
            this.lineShape33.X1 = 830;
            this.lineShape33.X2 = 830;
            this.lineShape33.Y1 = 51;
            this.lineShape33.Y2 = 370;
            // 
            // lineShape32
            // 
            this.lineShape32.Name = "lineShape32";
            this.lineShape32.X1 = 830;
            this.lineShape32.X2 = 1200;
            this.lineShape32.Y1 = 370;
            this.lineShape32.Y2 = 370;
            // 
            // lineShape31
            // 
            this.lineShape31.Name = "lineShape31";
            this.lineShape31.X1 = 830;
            this.lineShape31.X2 = 1200;
            this.lineShape31.Y1 = 291;
            this.lineShape31.Y2 = 291;
            // 
            // lineShape30
            // 
            this.lineShape30.Name = "lineShape30";
            this.lineShape30.X1 = 830;
            this.lineShape30.X2 = 1200;
            this.lineShape30.Y1 = 261;
            this.lineShape30.Y2 = 261;
            // 
            // lineShape29
            // 
            this.lineShape29.Name = "lineShape29";
            this.lineShape29.X1 = 830;
            this.lineShape29.X2 = 1200;
            this.lineShape29.Y1 = 231;
            this.lineShape29.Y2 = 231;
            // 
            // lineShape28
            // 
            this.lineShape28.Name = "lineShape28";
            this.lineShape28.X1 = 830;
            this.lineShape28.X2 = 1200;
            this.lineShape28.Y1 = 201;
            this.lineShape28.Y2 = 201;
            // 
            // lineShape27
            // 
            this.lineShape27.Name = "lineShape27";
            this.lineShape27.X1 = 830;
            this.lineShape27.X2 = 1200;
            this.lineShape27.Y1 = 171;
            this.lineShape27.Y2 = 171;
            // 
            // lineShape26
            // 
            this.lineShape26.Name = "lineShape26";
            this.lineShape26.X1 = 830;
            this.lineShape26.X2 = 1200;
            this.lineShape26.Y1 = 141;
            this.lineShape26.Y2 = 141;
            // 
            // hidLine28
            // 
            this.hidLine28.Name = "hidLine28";
            this.hidLine28.X1 = 830;
            this.hidLine28.X2 = 1200;
            this.hidLine28.Y1 = 430;
            this.hidLine28.Y2 = 430;
            // 
            // hidLine29
            // 
            this.hidLine29.Name = "hidLine29";
            this.hidLine29.X1 = 830;
            this.hidLine29.X2 = 1200;
            this.hidLine29.Y1 = 400;
            this.hidLine29.Y2 = 400;
            // 
            // hidLine21
            // 
            this.hidLine21.Name = "hidLine21";
            this.hidLine21.X1 = 830;
            this.hidLine21.X2 = 1200;
            this.hidLine21.Y1 = 21;
            this.hidLine21.Y2 = 21;
            // 
            // lineShape22
            // 
            this.lineShape22.Name = "lineShape22";
            this.lineShape22.X1 = 830;
            this.lineShape22.X2 = 1200;
            this.lineShape22.Y1 = 111;
            this.lineShape22.Y2 = 111;
            // 
            // lineShape21
            // 
            this.lineShape21.Name = "lineShape21";
            this.lineShape21.X1 = 830;
            this.lineShape21.X2 = 1200;
            this.lineShape21.Y1 = 81;
            this.lineShape21.Y2 = 81;
            // 
            // lineShape20
            // 
            this.lineShape20.Name = "lineShape20";
            this.lineShape20.X1 = 830;
            this.lineShape20.X2 = 1200;
            this.lineShape20.Y1 = 51;
            this.lineShape20.Y2 = 51;
            // 
            // hidLine22
            // 
            this.hidLine22.Name = "hidLine22";
            this.hidLine22.X1 = 830;
            this.hidLine22.X2 = 830;
            this.hidLine22.Y1 = 21;
            this.hidLine22.Y2 = 51;
            // 
            // hidLine23
            // 
            this.hidLine23.Name = "hidLine23";
            this.hidLine23.X1 = 910;
            this.hidLine23.X2 = 910;
            this.hidLine23.Y1 = 21;
            this.hidLine23.Y2 = 51;
            // 
            // hidLine24
            // 
            this.hidLine24.Name = "hidLine24";
            this.hidLine24.X1 = 1200;
            this.hidLine24.X2 = 1200;
            this.hidLine24.Y1 = 21;
            this.hidLine24.Y2 = 51;
            // 
            // hidLine25
            // 
            this.hidLine25.Name = "hidLine25";
            this.hidLine25.X1 = 830;
            this.hidLine25.X2 = 830;
            this.hidLine25.Y1 = 370;
            this.hidLine25.Y2 = 430;
            // 
            // hidLine26
            // 
            this.hidLine26.Name = "hidLine26";
            this.hidLine26.X1 = 910;
            this.hidLine26.X2 = 910;
            this.hidLine26.Y1 = 370;
            this.hidLine26.Y2 = 430;
            // 
            // hidLine27
            // 
            this.hidLine27.Name = "hidLine27";
            this.hidLine27.X1 = 1200;
            this.hidLine27.X2 = 1200;
            this.hidLine27.Y1 = 370;
            this.hidLine27.Y2 = 430;
            // 
            // CompanyMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.tabControl1);
            this.Name = "CompanyMain";
            this.Size = new System.Drawing.Size(1263, 658);
            this.Load += new System.EventHandler(this.CompanyMain_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SellerList)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.buyerList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView SellerList;
        private System.Windows.Forms.Label lblTest;
        private System.Windows.Forms.TextBox txtMemo;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.TextBox txtHp;
        private System.Windows.Forms.TextBox txtTel;
        private System.Windows.Forms.TextBox txtAddr;
        private System.Windows.Forms.TextBox txtBank;
        private System.Windows.Forms.TextBox txtBankNo;
        private System.Windows.Forms.TextBox txtBankOwner;
        private System.Windows.Forms.TextBox txtCompany;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblRegister;
        private System.Windows.Forms.Label lblCode;
        private System.Windows.Forms.Label lblCodeName;
        private System.Windows.Forms.Label lblTitle2;
        private System.Windows.Forms.Label lblTitle1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblError;
        private System.Windows.Forms.Label lblError2;
        private System.Windows.Forms.TextBox txtMemo2;
        private System.Windows.Forms.TextBox txtContact2;
        private System.Windows.Forms.TextBox txtHp2;
        private System.Windows.Forms.TextBox txtTel2;
        private System.Windows.Forms.TextBox txtAddr2;
        private System.Windows.Forms.TextBox txtBank2;
        private System.Windows.Forms.TextBox txtBankNo2;
        private System.Windows.Forms.TextBox txtBankOwner2;
        private System.Windows.Forms.TextBox txtCompany2;
        private System.Windows.Forms.Label lblDate2;
        private System.Windows.Forms.Label lblRegister2;
        private System.Windows.Forms.Label lblCode2;
        private System.Windows.Forms.Label lblCodeName2;
        private System.Windows.Forms.Label lblTitle12;
        private System.Windows.Forms.Label lblTitle11;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button btnDel2;
        private System.Windows.Forms.Button btnSave2;
        private System.Windows.Forms.Button btnNew2;
        private System.Windows.Forms.DataGridView buyerList;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnNew;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.LineShape hidLine2;
        private Microsoft.VisualBasic.PowerPacks.LineShape hidLine1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape10;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape9;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape8;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape7;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape6;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape5;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape4;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape hidLine3;
        private Microsoft.VisualBasic.PowerPacks.LineShape hidLine9;
        private Microsoft.VisualBasic.PowerPacks.LineShape hidLine8;
        private Microsoft.VisualBasic.PowerPacks.LineShape hidLine7;
        private Microsoft.VisualBasic.PowerPacks.LineShape hidLine6;
        private Microsoft.VisualBasic.PowerPacks.LineShape hidLine5;
        private Microsoft.VisualBasic.PowerPacks.LineShape hidLine4;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape13;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape12;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape11;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape35;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape34;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape33;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape32;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape31;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape30;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape29;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape28;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape27;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape26;
        private Microsoft.VisualBasic.PowerPacks.LineShape hidLine28;
        private Microsoft.VisualBasic.PowerPacks.LineShape hidLine29;
        private Microsoft.VisualBasic.PowerPacks.LineShape hidLine21;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape22;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape21;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape20;
        private Microsoft.VisualBasic.PowerPacks.LineShape hidLine22;
        private Microsoft.VisualBasic.PowerPacks.LineShape hidLine23;
        private Microsoft.VisualBasic.PowerPacks.LineShape hidLine24;
        private Microsoft.VisualBasic.PowerPacks.LineShape hidLine25;
        private Microsoft.VisualBasic.PowerPacks.LineShape hidLine26;
        private Microsoft.VisualBasic.PowerPacks.LineShape hidLine27;
    }
}
